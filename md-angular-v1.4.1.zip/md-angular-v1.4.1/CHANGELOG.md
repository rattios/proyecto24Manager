## [1.4.1] - 2017-09-19
### Material
- added material.init()
- fixed input float problem
- fixed checkboxes in tabs

## [1.4.0] - 2017-08-23
### Changes for Angular 4
- added angular-cli
- update to Angular 4

## [v1.3.0] 2017-08-23
### skipped for sync with Angular 4 version convention

## [1.2.0] - 2017-04-05
### Added
- added Upgrade to PRO page
- update package
- made sidebar dynamic

## [1.1.1] - 2017-03-21
### Added
- added "@types/core-js": "0.9.35" in package

## [1.1.0] - 2017-03-20
### small fix

## [1.0.0] - 2017-01-30
### initial Release
